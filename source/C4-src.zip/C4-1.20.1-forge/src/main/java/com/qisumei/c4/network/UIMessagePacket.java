package com.qisumei.c4.network;

import com.qisumei.c4.client.ClientMessageRenderer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class UIMessagePacket {
    private final String message;
    private final int duration;
    private final boolean isSelfOnly;

    public UIMessagePacket(String message, int duration, boolean isSelfOnly) {
        this.message = message;
        this.duration = duration;
        this.isSelfOnly = isSelfOnly;
    }

    public UIMessagePacket(String message, int duration) {
        this(message, duration, false);
    }

    public static void encode(UIMessagePacket packet, FriendlyByteBuf buf) {
        buf.writeUtf(packet.message);
        buf.writeInt(packet.duration);
        buf.writeBoolean(packet.isSelfOnly);
    }

    public static UIMessagePacket decode(FriendlyByteBuf buf) {
        return new UIMessagePacket(buf.readUtf(), buf.readInt(), buf.readBoolean());
    }

    public static void handle(UIMessagePacket packet, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            String message = packet.message;
            int duration = packet.duration;

            if ("INSTALL_START".equals(message)) {
                ClientMessageRenderer.startInstallCountdown();
            } else if ("DEFUSE_SHEARS_START".equals(message)) {
                ClientMessageRenderer.startDefuseShearsCountdown();
            } else if ("DEFUSE_EMPTY_START".equals(message)) {
                ClientMessageRenderer.startDefuseEmptyCountdown();
            } else {
                ClientMessageRenderer.showMessage(Component.literal(message), duration);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}