package com.qisumei.c4.item;

import com.qisumei.c4.Config;
import com.qisumei.c4.entity.C4Entity;
import com.qisumei.c4.network.PacketHandler;
import com.qisumei.c4.qis4c4;
import com.qisumei.c4.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.scores.Team;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nonnull;
import java.util.List;

public class C4Item extends Item {
    private static final int USE_DURATION = 70;
    private static final int CANCEL_THRESHOLD = 10;
    private static final ThreadLocal<Boolean> isCompleted = ThreadLocal.withInitial(() -> false);
    private static final ThreadLocal<Long> lastInstallTeamCheckTime = ThreadLocal.withInitial(() -> 0L);
    private static String cachedInstallTeamName = "";

    public C4Item() {
        super(new Item.Properties().stacksTo(1));
    }

    @Override
    @Nonnull
    public UseAnim getUseAnimation(@Nonnull ItemStack stack) {
        return UseAnim.BLOCK;
    }

    private static Block getStandingBlock(Player player, Level world) {
        BlockPos playerPos = player.blockPosition();
        BlockPos belowPos = playerPos.below();
        BlockState belowState = world.getBlockState(belowPos);
        return belowState.getBlock();
    }

    // 获取玩家队伍名称
    private static String getPlayerTeamName(Player player) {
        Team team = player.getTeam();
        if (team == null) {
            return "";
        }
        return team.getName();
    }

    // 检测安装队伍是否允许（无日志，低频缓存）
    private static boolean isInstallTeamAllowed(Player player) {
        if (Config.allowedInstallTeams == null || Config.allowedInstallTeams.isEmpty()) {
            return true;
        }

        long now = System.currentTimeMillis();
        long last = lastInstallTeamCheckTime.get();
        if (now - last < 500 && cachedInstallTeamName != null) {
            return Config.allowedInstallTeams.contains(cachedInstallTeamName);
        }
        lastInstallTeamCheckTime.set(now);

        String teamName = getPlayerTeamName(player);
        cachedInstallTeamName = teamName;

        if (teamName.isEmpty()) {
            return Config.allowedInstallTeams.contains("");
        }
        return Config.allowedInstallTeams.contains(teamName);
    }

    private static void sendToPlayer(Level world, Player player, String message, int duration) {
        if (!world.isClientSide && player instanceof ServerPlayer serverPlayer) {
            PacketHandler.sendToPlayer(serverPlayer, message, duration);
        }
    }

    @Override
    @Nonnull
    public InteractionResultHolder<ItemStack> use(@Nonnull Level world, @Nonnull Player player, @Nonnull InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        // 检查安装队伍权限
        if (!isInstallTeamAllowed(player)) {
            String allowedTeams = String.join(", ", Config.allowedInstallTeams);
            sendToPlayer(world, player, "§c 您的队伍不允许安装C4！允许的队伍: §e" + allowedTeams, 3000);
            return InteractionResultHolder.fail(stack);
        }

        Block standingBlock = getStandingBlock(player, world);
        String blockId = ForgeRegistries.BLOCKS.getKey(standingBlock).toString();

        List<? extends String> allowedBlocks = Config.allowedBlocks;
        if (allowedBlocks == null || !allowedBlocks.contains(blockId)) {
            String allowedList = allowedBlocks != null ? String.join(", ", allowedBlocks) : "minecraft:end_stone_bricks";
            sendToPlayer(world, player, "§c C4只能放置在指定方块上！允许: §e" + allowedList, 3000);
            return InteractionResultHolder.fail(stack);
        }

        player.startUsingItem(hand);
        isCompleted.set(false);
        sendToPlayer(world, player, "INSTALL_START", 0);

        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void releaseUsing(@Nonnull ItemStack stack, @Nonnull Level world, @Nonnull LivingEntity user, int timeCharged) {
        if (!(user instanceof Player player)) return;

        if (isCompleted.get()) {
            isCompleted.remove();
            return;
        }

        int usedTicks = USE_DURATION - timeCharged;

        if (usedTicks < CANCEL_THRESHOLD) {
            sendToPlayer(world, player, "§c 安装已取消！ ", 2000);
        } else if (usedTicks < USE_DURATION) {
            sendToPlayer(world, player, "§c 安装中断！请长按完成安装 ", 2000);
        }

        isCompleted.remove();
    }

    @Override
    public void onUseTick(@Nonnull Level world, @Nonnull LivingEntity user, @Nonnull ItemStack stack, int remainingUseTicks) {
        if (!(user instanceof Player player) || world.isClientSide) return;

        int usedTicks = USE_DURATION - remainingUseTicks;

        if (usedTicks > 0 && usedTicks < USE_DURATION) {
            player.setDeltaMovement(0, player.getDeltaMovement().y, 0);
            player.setSprinting(false);
            player.hurtMarked = true;
        }

        if (remainingUseTicks == 1) {
            isCompleted.set(true);

            if (!isInstallTeamAllowed(player)) {
                String allowedTeams = String.join(", ", Config.allowedInstallTeams);
                sendToPlayer(world, player, "§c 您的队伍不允许安装C4！允许的队伍: §e" + allowedTeams, 3000);
                return;
            }

            Block standingBlock = getStandingBlock(player, world);
            String blockId = ForgeRegistries.BLOCKS.getKey(standingBlock).toString();

            List<? extends String> allowedBlocks = Config.allowedBlocks;
            if (allowedBlocks == null || !allowedBlocks.contains(blockId)) {
                sendToPlayer(world, player, "§c C4只能放置在指定方块上！当前: §e" + blockId, 3000);
                return;
            }

            BlockPos placePos = player.blockPosition();

            if (!world.getBlockState(placePos).canBeReplaced()) {
                placePos = placePos.above();
                if (!world.getBlockState(placePos).canBeReplaced()) {
                    sendToPlayer(world, player, "§c 无法在此位置安装C4！ ", 2000);
                    return;
                }
            }

            world.playSound(null, placePos,
                    SoundEvents.NOTE_BLOCK_HAT.value(),
                    SoundSource.BLOCKS, 0.8f, 0.9f);

            if (world instanceof ServerLevel serverLevel) {
                C4Entity c4Entity = new C4Entity(world, placePos, true);
                serverLevel.addFreshEntity(c4Entity);
            }

            sendToPlayer(world, player, "§a C4已安装在脚下！40秒后引爆 ", 3000);

            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
        }
    }

    @Override
    public int getUseDuration(@Nonnull ItemStack stack) {
        return USE_DURATION;
    }
}