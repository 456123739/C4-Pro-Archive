package com.qisumei.c4.handler;

import com.qisumei.c4.Config;
import com.qisumei.c4.client.ClientMessageRenderer;
import com.qisumei.c4.entity.C4Entity;
import com.qisumei.c4.qis4c4;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = qis4c4.MODID)
public class C4InteractionHandler {

    private static final Map<UUID, Integer> activeDefusing = new HashMap<>();
    private static final Map<UUID, BlockPos> defusingPosition = new HashMap<>();
    private static final Map<UUID, String> defusingItem = new HashMap<>();
    private static final Map<UUID, Long> lastWarningTime = new HashMap<>();
    private static final double MAX_DISTANCE = 4.0;

    private static C4Entity getLookedAtC4(Player player) {
        double reachDistance = MAX_DISTANCE;
        Vec3 eyePosition = player.getEyePosition();
        Vec3 lookVector = player.getViewVector(1.0F);
        Vec3 endPosition = eyePosition.add(lookVector.x * reachDistance, lookVector.y * reachDistance, lookVector.z * reachDistance);

        AABB boundingBox = player.getBoundingBox().inflate(reachDistance);
        var entities = player.level().getEntities(player, boundingBox, e -> e instanceof C4Entity);

        C4Entity closest = null;
        double closestDistance = reachDistance + 1;

        for (var entity : entities) {
            C4Entity c4 = (C4Entity) entity;
            var hitResult = c4.getBoundingBox().clip(eyePosition, endPosition);
            if (hitResult.isPresent()) {
                double distance = eyePosition.distanceTo(hitResult.get());
                if (distance < closestDistance) {
                    closestDistance = distance;
                    closest = c4;
                }
            }
        }

        return closest;
    }

    private static String getPlayerTeamName(Player player) {
        net.minecraft.world.scores.Team team = player.getTeam();
        if (team == null) return "";
        return team.getName();
    }

    private static boolean isDefuseTeamAllowedLocal(Player player) {
        if (Config.allowedDefuseTeams == null || Config.allowedDefuseTeams.isEmpty()) {
            return true;
        }
        String teamName = getPlayerTeamName(player);
        if (teamName.isEmpty()) {
            return Config.allowedDefuseTeams.contains("");
        }
        return Config.allowedDefuseTeams.contains(teamName);
    }

    /**
     * 处理右键点击实体（包括空手）
     * 这个事件会在玩家空手右键点击C4时触发
     */
    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof C4Entity c4)) {
            return;
        }

        Player player = event.getEntity();
        event.setCanceled(true);

        // 客户端检测和提示
        if (player.level().isClientSide) {
            long now = System.currentTimeMillis();
            Long last = lastWarningTime.get(player.getUUID());
            boolean canShow = (last == null || now - last > 500);

            ItemStack mainHand = player.getMainHandItem();
            boolean hasShears = mainHand.is(Items.SHEARS);
            boolean isEmptyHand = mainHand.isEmpty();

            // 允许剪刀或空手
            if (!hasShears && !isEmptyHand) {
                if (canShow) {
                    ClientMessageRenderer.showMessage(Component.literal("§c 需要使用剪刀（5秒）或空手（10秒）拆除C4！"), 3000);
                    lastWarningTime.put(player.getUUID(), now);
                }
                return;
            }

            if (!isDefuseTeamAllowedLocal(player)) {
                if (canShow) {
                    String allowedTeams = String.join(", ", Config.allowedDefuseTeams);
                    ClientMessageRenderer.showMessage(Component.literal("§c 您的队伍不允许拆除C4！允许的队伍: §e" + allowedTeams), 3000);
                    lastWarningTime.put(player.getUUID(), now);
                }
                return;
            }

            if (c4.isBeingDefused() && !c4.isDefusingBy(player)) {
                if (canShow) {
                    ClientMessageRenderer.showMessage(Component.literal("§c C4正在被其他玩家拆除！"), 2000);
                    lastWarningTime.put(player.getUUID(), now);
                }
                return;
            }
            return;
        }

        // 服务端处理
        ItemStack mainHand = player.getMainHandItem();
        boolean hasShears = mainHand.is(Items.SHEARS);
        boolean isEmptyHand = mainHand.isEmpty();

        // 空手或剪刀都能触发拆除
        if (hasShears || isEmptyHand) {
            UUID playerId = player.getUUID();
            int c4Id = c4.getId();

            if (activeDefusing.containsKey(playerId) && activeDefusing.get(playerId) == c4Id) {
                return;
            }

            boolean started = c4.startDefusing(player);
            if (started) {
                activeDefusing.put(playerId, c4Id);
                defusingPosition.put(playerId, player.blockPosition());
                defusingItem.put(playerId, hasShears ? "剪刀" : "空手");
            }
        }
    }

    /**
     * 备用：处理右键点击物品（当玩家手持物品时）
     */
    @SubscribeEvent
    public static void onRightClick(PlayerInteractEvent.RightClickItem event) {
        Player player = event.getEntity();
        C4Entity lookedAtC4 = getLookedAtC4(player);

        if (lookedAtC4 == null) {
            return;
        }

        // 如果玩家手持物品，使用这个事件处理
        ItemStack mainHand = player.getMainHandItem();
        if (mainHand.isEmpty()) {
            return; // 空手由 EntityInteract 处理
        }

        event.setCanceled(true);

        // 客户端检测和提示（简化，因为手持物品时已经由 EntityInteract 处理了大部分）
        if (player.level().isClientSide) {
            if (!mainHand.is(Items.SHEARS)) {
                long now = System.currentTimeMillis();
                Long last = lastWarningTime.get(player.getUUID());
                if (last == null || now - last > 500) {
                    ClientMessageRenderer.showMessage(Component.literal("§c 需要使用剪刀（5秒）或空手（10秒）拆除C4！"), 3000);
                    lastWarningTime.put(player.getUUID(), now);
                }
                return;
            }
            return;
        }

        // 服务端处理（仅剪刀）
        if (mainHand.is(Items.SHEARS)) {
            UUID playerId = player.getUUID();
            int c4Id = lookedAtC4.getId();

            if (activeDefusing.containsKey(playerId) && activeDefusing.get(playerId) == c4Id) {
                return;
            }

            boolean started = lookedAtC4.startDefusing(player);
            if (started) {
                activeDefusing.put(playerId, c4Id);
                defusingPosition.put(playerId, player.blockPosition());
                defusingItem.put(playerId, "剪刀");
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (event.player.level().isClientSide) return;

        Player player = event.player;
        UUID playerId = player.getUUID();

        Integer c4Id = activeDefusing.get(playerId);
        if (c4Id == null) return;

        C4Entity c4 = (C4Entity) player.level().getEntity(c4Id);
        if (c4 == null || c4.isRemoved()) {
            activeDefusing.remove(playerId);
            defusingPosition.remove(playerId);
            defusingItem.remove(playerId);
            return;
        }

        ItemStack mainHand = player.getMainHandItem();
        boolean hasShears = mainHand.is(Items.SHEARS);
        boolean isEmptyHand = mainHand.isEmpty();
        boolean canDefuse = hasShears || isEmptyHand;

        String currentItem = hasShears ? "剪刀" : (isEmptyHand ? "空手" : "其他");
        String lastItem = defusingItem.get(playerId);

        // 如果物品状态变化，取消拆除
        if (lastItem != null && !lastItem.equals(currentItem)) {
            c4.cancelDefusing(player);
            activeDefusing.remove(playerId);
            defusingPosition.remove(playerId);
            defusingItem.remove(playerId);
            return;
        }

        if (!canDefuse) {
            c4.cancelDefusing(player);
            activeDefusing.remove(playerId);
            defusingPosition.remove(playerId);
            defusingItem.remove(playerId);
            return;
        }

        BlockPos currentPos = player.blockPosition();
        BlockPos lastPos = defusingPosition.get(playerId);
        if (lastPos != null && !lastPos.equals(currentPos)) {
            c4.cancelDefusing(player);
            activeDefusing.remove(playerId);
            defusingPosition.remove(playerId);
            defusingItem.remove(playerId);
            return;
        }

        if (player.distanceTo(c4) > MAX_DISTANCE + 0.5) {
            c4.cancelDefusing(player);
            activeDefusing.remove(playerId);
            defusingPosition.remove(playerId);
            defusingItem.remove(playerId);
            return;
        }

        if (c4.isBeingDefused() && !c4.isDefusingBy(player)) {
            c4.cancelDefusing(player);
            activeDefusing.remove(playerId);
            defusingPosition.remove(playerId);
            defusingItem.remove(playerId);
            return;
        }
    }

    @SubscribeEvent
    public static void onLeftClick(PlayerInteractEvent.LeftClickBlock event) {
        cancelDefusing(event.getEntity());
    }

    @SubscribeEvent
    public static void onLeftClickEmpty(PlayerInteractEvent.LeftClickEmpty event) {
        cancelDefusing(event.getEntity());
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        Player player = event.getEntity();
        UUID playerId = player.getUUID();
        Integer c4Id = activeDefusing.get(playerId);
        if (c4Id != null) {
            C4Entity c4 = (C4Entity) player.level().getEntity(c4Id);
            if (c4 != null && !c4.isRemoved()) {
                c4.cancelDefusing(player);
                activeDefusing.remove(playerId);
                defusingPosition.remove(playerId);
                defusingItem.remove(playerId);
            } else {
                activeDefusing.remove(playerId);
                defusingPosition.remove(playerId);
                defusingItem.remove(playerId);
            }
        }
    }

    private static void cancelDefusing(Player player) {
        UUID playerId = player.getUUID();
        Integer c4Id = activeDefusing.remove(playerId);
        if (c4Id != null) {
            C4Entity c4 = (C4Entity) player.level().getEntity(c4Id);
            if (c4 != null && !c4.isRemoved()) {
                c4.cancelDefusing(player);
            }
        }
        defusingPosition.remove(playerId);
        defusingItem.remove(playerId);
    }
}