package com.qisumei.c4.entity;

import com.qisumei.c4.Config;
import com.qisumei.c4.ModInitializer;
import com.qisumei.c4.network.PacketHandler;
import com.qisumei.c4.network.UIMessagePacket;
import com.qisumei.c4.qis4c4;
import com.qisumei.c4.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.server.ServerLifecycleHooks;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class C4Entity extends Entity {

    private static final EntityDataAccessor<Integer> TICKS_LEFT =
            SynchedEntityData.defineId(C4Entity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> IS_PLAYER_PLACED =
            SynchedEntityData.defineId(C4Entity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<String> DEFUSING_PLAYER_UUID =
            SynchedEntityData.defineId(C4Entity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Long> DEFUSE_END_TIME =
            SynchedEntityData.defineId(C4Entity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Boolean> COUNTDOWN_SOUND_PLAYED =
            SynchedEntityData.defineId(C4Entity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> IS_LOADED =
            SynchedEntityData.defineId(C4Entity.class, EntityDataSerializers.BOOLEAN);

    private int nextBeepTick;
    private boolean announced20;
    private boolean announced4;
    private BlockPos myPos;
    private long lastProgressTime = 0;
    private boolean isChunkLoaded = false;
    private boolean wasChunkForceLoaded = false;

    // 拆除时间
    private static final int DEFUSE_SHEARS_DURATION_MS = 5000;   // 剪刀5秒
    private static final int DEFUSE_EMPTY_HAND_DURATION_MS = 10000; // 空手10秒

    private static final float WIDTH = 0.7f;
    private static final float HEIGHT = 0.2f;

    private String currentDefuser = "";
    private static final Map<UUID, Long> activeDefuseMap = new ConcurrentHashMap<>();

    public C4Entity(EntityType<? extends C4Entity> type, Level level) {
        super(type, level);
        this.noCulling = true;
    }

    public C4Entity(Level level, BlockPos pos, boolean playerPlaced) {
        this(qis4c4.C4_ENTITY.get(), level);
        this.setPos(pos.getX() + 0.5, pos.getY() + 0.1, pos.getZ() + 0.5);
        this.myPos = pos;
        this.entityData.set(TICKS_LEFT, 20 * 40);
        this.entityData.set(IS_PLAYER_PLACED, playerPlaced);
        this.entityData.set(DEFUSING_PLAYER_UUID, "");
        this.entityData.set(DEFUSE_END_TIME, 0L);
        this.entityData.set(COUNTDOWN_SOUND_PLAYED, false);
        this.entityData.set(IS_LOADED, false);
        this.nextBeepTick = calculateNextInterval(20 * 40);
        this.announced20 = false;
        this.announced4 = false;

        if (level instanceof ServerLevel serverLevel) {
            ChunkAccess chunk = serverLevel.getChunk(pos);
            this.isChunkLoaded = true;
            this.wasChunkForceLoaded = true;
            this.entityData.set(IS_LOADED, true);
        }

        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server != null) {
            ModInitializer.updateC4State(server, ModInitializer.STATE_PLACED);
            ModInitializer.updateC4Position(server, pos.getX(), pos.getY(), pos.getZ());
        }

        if (level instanceof ServerLevel) {
            C4EntityTracker.addC4(this);
        }
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(TICKS_LEFT, 20 * 40);
        this.entityData.define(IS_PLAYER_PLACED, true);
        this.entityData.define(DEFUSING_PLAYER_UUID, "");
        this.entityData.define(DEFUSE_END_TIME, 0L);
        this.entityData.define(COUNTDOWN_SOUND_PLAYED, false);
        this.entityData.define(IS_LOADED, false);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.entityData.set(TICKS_LEFT, tag.getInt("TicksLeft"));
        this.entityData.set(IS_PLAYER_PLACED, tag.getBoolean("PlayerPlaced"));
        this.nextBeepTick = tag.getInt("NextBeepTick");
        this.announced20 = tag.getBoolean("Announced20");
        this.announced4 = tag.getBoolean("Announced4");
        int x = tag.getInt("PosX");
        int y = tag.getInt("PosY");
        int z = tag.getInt("PosZ");
        this.myPos = new BlockPos(x, y, z);
        this.entityData.set(DEFUSE_END_TIME, tag.getLong("DefuseEndTime"));
        this.entityData.set(IS_LOADED, tag.getBoolean("IsLoaded"));
        this.wasChunkForceLoaded = tag.getBoolean("WasChunkForceLoaded");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("TicksLeft", this.entityData.get(TICKS_LEFT));
        tag.putBoolean("PlayerPlaced", this.entityData.get(IS_PLAYER_PLACED));
        tag.putInt("NextBeepTick", this.nextBeepTick);
        tag.putBoolean("Announced20", this.announced20);
        tag.putBoolean("Announced4", this.announced4);
        tag.putLong("DefuseEndTime", this.entityData.get(DEFUSE_END_TIME));
        tag.putBoolean("IsLoaded", this.entityData.get(IS_LOADED));
        tag.putBoolean("WasChunkForceLoaded", this.wasChunkForceLoaded);
        if (myPos != null) {
            tag.putInt("PosX", myPos.getX());
            tag.putInt("PosY", myPos.getY());
            tag.putInt("PosZ", myPos.getZ());
        }
    }

    @Override
    public void tick() {
        super.tick();

        if (!this.level().isClientSide && !this.entityData.get(IS_LOADED)) {
            if (this.level() instanceof ServerLevel serverLevel) {
                serverLevel.getChunk(this.blockPosition());
                this.entityData.set(IS_LOADED, true);
                this.isChunkLoaded = true;
                this.wasChunkForceLoaded = true;
            }
        }

        if (this.level().isClientSide) {
            return;
        }

        ServerLevel serverLevel = (ServerLevel) this.level();

        // 播放倒计时音效 - 使用更大音量让远处也能听到
        if (!this.entityData.get(COUNTDOWN_SOUND_PLAYED)) {
            this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                    ModSounds.C4_COUNTDOWN.get(),
                    SoundSource.BLOCKS,
                    3.0f,  // 音量增大到3.0，扩大传播范围
                    1.0f);
            this.entityData.set(COUNTDOWN_SOUND_PLAYED, true);
        }

        long defuseEndTime = this.entityData.get(DEFUSE_END_TIME);
        if (defuseEndTime > 0) {
            long currentTime = System.currentTimeMillis();
            if (currentTime >= defuseEndTime) {
                String defusingPlayerUuid = this.entityData.get(DEFUSING_PLAYER_UUID);
                if (!defusingPlayerUuid.isEmpty()) {
                    Player player = serverLevel.getPlayerByUUID(UUID.fromString(defusingPlayerUuid));
                    if (player != null) {
                        defuse(player);
                    } else {
                        defuse(null);
                    }
                }
                return;
            }
        }

        int ticksLeft = this.entityData.get(TICKS_LEFT);
        if (ticksLeft <= 0) {
            explode();
            return;
        }

        ticksLeft--;
        this.entityData.set(TICKS_LEFT, ticksLeft);

        if (ticksLeft <= this.nextBeepTick) {
            playAlarmSound(serverLevel);
            this.nextBeepTick = ticksLeft - calculateNextInterval(ticksLeft);
        }

        if (!announced20 && ticksLeft <= 20 * 20) {
            broadcastMessage(serverLevel, "§e 还剩 20 秒。");
            announced20 = true;
        }

        if (!announced4 && ticksLeft <= 4 * 20) {
            broadcastMessage(serverLevel, "§c 炸弹即将爆炸！");
            announced4 = true;
        }
    }

    @Override
    public void onRemovedFromWorld() {
        super.onRemovedFromWorld();
        if (!this.level().isClientSide) {
            C4EntityTracker.removeC4(this);
            MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
            if (server != null) {
                server.getCommands().performPrefixedCommand(
                        server.createCommandSourceStack().withSuppressedOutput(),
                        "stopsound @a * qis4c4:c4countdown"
                );
            }
        }
        unloadChunk();
    }

    private void unloadChunk() {
        if (this.level().isClientSide) return;
        if (this.myPos == null) return;
        if (!this.wasChunkForceLoaded) return;

        try {
            ServerLevel serverLevel = (ServerLevel) this.level();
            this.wasChunkForceLoaded = false;
        } catch (Exception e) {
            // 忽略
        }
    }

    @Nonnull
    @Override
    public AABB getBoundingBoxForCulling() {
        return new AABB(this.getX() - WIDTH/2, this.getY(), this.getZ() - WIDTH/2,
                this.getX() + WIDTH/2, this.getY() + HEIGHT, this.getZ() + WIDTH/2);
    }

    @Override
    public boolean isPickable() {
        return true;
    }

    @Override
    public float getPickRadius() {
        return 0.8f;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean isInvulnerable() {
        return true;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return true;
    }

    // ========== 队伍检测 ==========
    private static String getPlayerTeamName(Player player) {
        net.minecraft.world.scores.Team team = player.getTeam();
        if (team == null) {
            return "";
        }
        return team.getName();
    }

    private static boolean isDefuseTeamAllowed(Player player) {
        if (Config.allowedDefuseTeams == null || Config.allowedDefuseTeams.isEmpty()) {
            return true;
        }
        String teamName = getPlayerTeamName(player);
        if (teamName.isEmpty()) {
            return Config.allowedDefuseTeams.contains("");
        }
        return Config.allowedDefuseTeams.contains(teamName);
    }

    // ========== 检查是否可拆除（剪刀或空手） ==========
    private boolean canDefuse(Player player) {
        ItemStack mainHand = player.getMainHandItem();
        return mainHand.is(Items.SHEARS) || mainHand.isEmpty();
    }

    // ========== 获取拆除时间 ==========
    private int getDefuseDuration(Player player) {
        ItemStack mainHand = player.getMainHandItem();
        if (mainHand.is(Items.SHEARS)) {
            return DEFUSE_SHEARS_DURATION_MS;
        }
        return DEFUSE_EMPTY_HAND_DURATION_MS;
    }

    // ========== 拆除相关方法 ==========

    public boolean startDefusing(Player player) {
        if (!isDefuseTeamAllowed(player)) {
            String allowedTeams = String.join(", ", Config.allowedDefuseTeams);
            sendUIMessage("§c 您的队伍不允许拆除C4！允许的队伍: §e" + allowedTeams, 3000);
            return false;
        }

        if (!canDefuse(player)) {
            sendUIMessage("§c 需要使用剪刀（5秒）或空手（10秒）拆除C4！", 3000);
            return false;
        }

        UUID playerId = player.getUUID();
        String playerIdStr = playerId.toString();

        String currentDefuserUuid = this.entityData.get(DEFUSING_PLAYER_UUID);
        if (!currentDefuserUuid.isEmpty()) {
            long endTime = this.entityData.get(DEFUSE_END_TIME);
            if (endTime > System.currentTimeMillis()) {
                if (!currentDefuserUuid.equals(playerIdStr)) {
                    sendUIMessage("§c C4正在被其他玩家拆除！", 2000);
                    return false;
                }
                return true;
            }
        }

        long endTime = System.currentTimeMillis() + getDefuseDuration(player);
        this.entityData.set(DEFUSING_PLAYER_UUID, playerIdStr);
        this.entityData.set(DEFUSE_END_TIME, endTime);
        lastProgressTime = System.currentTimeMillis();
        this.currentDefuser = playerIdStr;

        ItemStack mainHand = player.getMainHandItem();
        boolean hasShears = mainHand.is(Items.SHEARS);
        String toolType = hasShears ? "剪刀" : "空手";
        String timeText = hasShears ? "5秒" : "10秒";
        sendUIMessage("§e " + player.getName().getString() + " 开始用" + toolType + "拆除C4...（" + timeText + "）", 2000);

        if (player instanceof ServerPlayer serverPlayer) {
            // 发送正确的信号到客户端
            if (hasShears) {
                PacketHandler.sendToPlayer(serverPlayer, "DEFUSE_SHEARS_START", 0);
            } else {
                PacketHandler.sendToPlayer(serverPlayer, "DEFUSE_EMPTY_START", 0);
            }
        }

        return true;
    }

    public void cancelDefusing(Player player) {
        String currentDefusingPlayer = this.entityData.get(DEFUSING_PLAYER_UUID);
        if (currentDefusingPlayer.isEmpty()) return;

        if (currentDefusingPlayer.equals(player.getUUID().toString())) {
            this.entityData.set(DEFUSING_PLAYER_UUID, "");
            this.entityData.set(DEFUSE_END_TIME, 0L);
            this.currentDefuser = "";
            sendUIMessage("§c " + player.getName().getString() + " 拆除中断！ ", 2000);
        }
    }

    public boolean isBeingDefused() {
        return this.entityData.get(DEFUSE_END_TIME) > System.currentTimeMillis();
    }

    public boolean isDefusingBy(Player player) {
        String currentDefusingPlayer = this.entityData.get(DEFUSING_PLAYER_UUID);
        if (currentDefusingPlayer.isEmpty()) return false;
        return currentDefusingPlayer.equals(player.getUUID().toString());
    }

    private void defuse(Player player) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server != null) {
            ModInitializer.updateC4State(server, ModInitializer.STATE_DEFUSED);
            ModInitializer.clearC4Position(server);

            server.getCommands().performPrefixedCommand(
                    server.createCommandSourceStack().withSuppressedOutput(),
                    "stopsound @a * qis4c4:c4countdown"
            );
        }
        this.currentDefuser = "";

        sendUIMessage("§a 炸弹已被拆除！", 2000);

        this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                ModSounds.CTW_SOUND.get(),
                SoundSource.BLOCKS, 1.5f, 1.0f);

        this.discard();
    }

    private void explode() {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server != null) {
            ModInitializer.updateC4State(server, ModInitializer.STATE_EXPLODED);
            ModInitializer.clearC4Position(server);

            server.getCommands().performPrefixedCommand(
                    server.createCommandSourceStack().withSuppressedOutput(),
                    "stopsound @a * qis4c4:c4countdown"
            );
        }
        this.currentDefuser = "";

        // 爆炸音效使用更大音量
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                ModSounds.TW_SOUND.get(),
                SoundSource.BLOCKS,
                10.0f,  // 爆炸音量
                0.8f);

        this.level().explode(null, this.getX(), this.getY(), this.getZ(),
                4.0f, Level.ExplosionInteraction.NONE);

        this.discard();
    }

    // ========== 辅助方法 ==========

    private void sendUIMessage(String message, int duration) {
        if (!this.level().isClientSide) {
            PacketHandler.INSTANCE.send(PacketDistributor.ALL.noArg(), new UIMessagePacket(message, duration));
        }
    }

    private void playAlarmSound(ServerLevel world) {
        world.playSound(null, this.getX(), this.getY(), this.getZ(),
                ModSounds.ALARM_SOUND(),
                SoundSource.BLOCKS, 1.5f, 1.0f);
    }

    private void broadcastMessage(ServerLevel world, String message) {
        world.getServer().getPlayerList().getPlayers().forEach(p ->
                p.sendSystemMessage(net.minecraft.network.chat.Component.literal(message))
        );
    }

    private int calculateNextInterval(int remainingTicks) {
        float progress = 1 - (remainingTicks / (40f * 20));
        return Math.max(8, (int)(40 * (1 - progress * 0.8f)));
    }

    @SuppressWarnings("unused")
    public int getRemainingTicks() {
        return this.entityData.get(TICKS_LEFT);
    }

    public BlockPos getC4Pos() {
        return this.myPos;
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return new ClientboundAddEntityPacket(this);
    }
}