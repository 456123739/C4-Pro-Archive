package com.qisumei.c4.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(value = Dist.CLIENT, modid = "qis4c4")
public class ClientMessageRenderer {

    private static class MessageData {
        String text;
        long expireTime;
        boolean isCountdown;
        long startTime;
        int totalDuration;  // 总时长（毫秒）
        String type;        // "install", "defuse_shears", "defuse_empty"
        long lastUpdateTime = 0;

        private static final DecimalFormat FORMAT = new DecimalFormat("0.0");

        MessageData(String text, long expireTime) {
            this.text = text;
            this.expireTime = expireTime;
            this.isCountdown = false;
            this.type = "message";
        }

        MessageData(long startTime, int totalDuration, String type) {
            this.text = "";
            this.isCountdown = true;
            this.startTime = startTime;
            this.totalDuration = totalDuration;
            this.type = type;
            this.expireTime = startTime + totalDuration + 500;
            this.lastUpdateTime = startTime;
        }

        boolean isExpired() {
            return System.currentTimeMillis() > expireTime;
        }

        String getCountdownText() {
            if (!isCountdown) return text;
            long now = System.currentTimeMillis();
            long elapsed = now - startTime;
            double remaining = Math.max(0, (totalDuration - elapsed) / 1000.0);

            if (remaining <= 0.05) return null;

            String remainingStr = FORMAT.format(remaining);

            if ("install".equals(type)) {
                return "§e 安装中... " + remainingStr + " 秒 ";
            } else if ("defuse_shears".equals(type)) {
                return "§e 剪刀拆除中... " + remainingStr + " 秒 ";
            } else if ("defuse_empty".equals(type)) {
                return "§e 空手拆除中... " + remainingStr + " 秒 ";
            }
            return text;
        }
    }

    private static final Map<UUID, MessageData> currentMessages = new HashMap<>();

    private static long lastRenderTime = 0;
    private static String cachedText = "";
    private static int cachedX = 0;
    private static int cachedY = 0;
    private static final long UPDATE_INTERVAL_MS = 100;
    private static final int Y_OFFSET = -30;

    public static void showMessage(Component message, int durationMs) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        UUID playerId = mc.player.getUUID();
        long expireTime = System.currentTimeMillis() + durationMs;
        currentMessages.put(playerId, new MessageData(message.getString(), expireTime));
        updateCache(mc);
    }

    /**
     * 开始安装倒计时（4秒）
     */
    public static void startInstallCountdown() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        UUID playerId = mc.player.getUUID();
        long now = System.currentTimeMillis();
        int totalMs = 4000;
        MessageData msg = new MessageData(now, totalMs, "install");
        currentMessages.put(playerId, msg);
        updateCache(mc);
    }

    /**
     * 开始剪刀拆除倒计时（5秒）
     */
    public static void startDefuseShearsCountdown() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        UUID playerId = mc.player.getUUID();
        long now = System.currentTimeMillis();
        int totalMs = 5000;
        MessageData msg = new MessageData(now, totalMs, "defuse_shears");
        currentMessages.put(playerId, msg);
        updateCache(mc);
    }

    /**
     * 开始空手拆除倒计时（10秒）
     */
    public static void startDefuseEmptyCountdown() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        UUID playerId = mc.player.getUUID();
        long now = System.currentTimeMillis();
        int totalMs = 10000;
        MessageData msg = new MessageData(now, totalMs, "defuse_empty");
        currentMessages.put(playerId, msg);
        updateCache(mc);
    }

    public static void clearMessage() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            currentMessages.remove(mc.player.getUUID());
        }
        cachedText = "";
    }

    private static void updateCache(Minecraft mc) {
        if (mc.player == null) return;

        UUID playerId = mc.player.getUUID();
        MessageData msg = currentMessages.get(playerId);

        if (msg == null || msg.isExpired()) {
            if (msg != null && msg.isExpired()) {
                currentMessages.remove(playerId);
            }
            cachedText = "";
            return;
        }

        String displayText = msg.isCountdown ? msg.getCountdownText() : msg.text;
        if (displayText == null || displayText.isEmpty()) {
            cachedText = "";
            if (msg.isCountdown) {
                currentMessages.remove(playerId);
            }
            return;
        }

        Font font = mc.font;
        int screenWidth = mc.getWindow().getGuiScaledWidth();
        int textWidth = font.width(displayText);
        cachedX = (screenWidth - textWidth) / 2;
        cachedY = mc.getWindow().getGuiScaledHeight() / 2 + Y_OFFSET;
        cachedText = displayText;
        lastRenderTime = System.currentTimeMillis();
    }

    private static void cleanExpiredMessages() {
        long now = System.currentTimeMillis();
        currentMessages.entrySet().removeIf(entry -> entry.getValue().isExpired());
    }

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        cleanExpiredMessages();

        UUID playerId = mc.player.getUUID();
        MessageData msg = currentMessages.get(playerId);

        if (msg == null || msg.isExpired()) {
            cachedText = "";
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastRenderTime >= UPDATE_INTERVAL_MS) {
            updateCache(mc);
        }

        if (cachedText.isEmpty()) return;

        GuiGraphics guiGraphics = event.getGuiGraphics();
        Font font = mc.font;
        guiGraphics.drawString(font, cachedText, cachedX, cachedY, 0xFFFFFF, false);
    }
}